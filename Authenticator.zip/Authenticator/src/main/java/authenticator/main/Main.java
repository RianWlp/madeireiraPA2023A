/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package authenticator.main;

import authenticator.negocio.Authenticator;
import authenticator.negocio.Funcionario;
import authenticator.negocio.User;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author rianwlp
 */
public class Main {

    public static void main(String[] args) {
        
        Funcionario f1 = new Funcionario("marco" ,"123".hashCode()+"");
        Funcionario f2 = new Funcionario("julio" ,"123".hashCode()+"");
        Funcionario f3 = new Funcionario("carla" ,"123".hashCode()+"");
        Funcionario f4 = new Funcionario("maria" ,"123".hashCode()+"");
        Funcionario f5 = new Funcionario("sandro","123".hashCode()+"");
        
        ArrayList<User> users = new ArrayList();

        users.add(f1);
        users.add(f2);
        users.add(f3);
        users.add(f4);
        users.add(f5);
        
        Authenticator auth = new Authenticator( users );
        auth.showDialog();
        
        
      if (auth.isRight("sandro","123")){
            
            // entrar no sistema
            System.out.println("Entrar no sistema");
            
        }else{
            
            JOptionPane.showMessageDialog(null, "Usuário ou senha incorretos");
            System.exit(0);
        }
    }
}


