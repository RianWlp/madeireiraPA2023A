package authenticator.negocio;

import authenticator.visao.JAuthenticator;
import java.util.ArrayList;

/**
 *
 * @author rianwlp
 */
public class Authenticator {
    
    private ArrayList<User> users = new ArrayList();
    private User loggedUser;
    
    public Authenticator(ArrayList<User> users){
    
        this.users = users;
    }
    
    public void setUsers(ArrayList<User> users){
     
        this.users = users;
    }
    
    public String getHashCode(String password){
    
        return password.hashCode()+"";
    }
     
    public boolean isRight( String username, String password ){
    
        if(("".equals(username)) && ("".equals(password))){
        
            return false;
        }
    
        for(User user : users){
            
            if((user.getHashCode().equals(password.hashCode()+"")) && (user.getLogName().equals(username))){
 
                User loggedUser = new Funcionario(user.getLogName(),user.getHashCode());
                return true;
            }
        }
        
        return false;
    }
    
    public void showDialog(){
     
        JAuthenticator tela = new JAuthenticator(null,true);
        tela.setVisible(true);
        
        System.out.println( tela.getLogName() );
        System.out.println( tela.getSenha() );
    }
    
    public User getLoggedUser(){
        
        return this.loggedUser;
    }
}