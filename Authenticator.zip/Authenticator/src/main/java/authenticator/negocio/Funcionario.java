package authenticator.negocio;

/**
 *
 * @author rianwlp
 */
public class Funcionario implements User{

    private String logName;
    private String name;
    private String password;
    
    public Funcionario(String logName, String password) {
        
        this.logName  = logName;
        this.password = password;
    }
    
    @Override
    public String getLogName() {
        
        return this.logName;
    }

    @Override
    public String getName() {
        
        return this.name;
    }

    @Override
    public String getHashCode() {
        
        return this.password;
    }
}
